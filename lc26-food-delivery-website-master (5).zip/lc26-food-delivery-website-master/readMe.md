# Responsive Food Delivery Website with HTML, CSS & JavaScript

![Responsive Food Delivery Website with HTML, CSS and JavaScript](https://raw.githubusercontent.com/wpcodevo/lc26-food-delivery-website/setup/restaurant%20food%20website.jpg "Responsive Food Delivery Website with HTML, CSS and JavaScript")

The Figma file of the Responsive Food Delivery Website can be found on my [website](https://codevoweb.com/lc26-build-food-ordering-website-html-css-javascript)
